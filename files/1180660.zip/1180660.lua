-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1180660)
addappid(1180661, 7944168128, "72a19a685d8cb6c64f161658219bf9ba99357042dc78c688d5f4045238367e6e")
setManifestid(1180661, "1121084895673538244", 8304209743)
addappid(1238430, 4851231024, "b71e20beeb0a44dea82ac77729b642341ab2258027aa98e2ff2dd572347d026e") -- Tell Me Why Chapter 2
setManifestid(1238430, "8556954704237120738", 4930597663)
addappid(1266670, 6023478304, "f813ea8876461b335086830b177793094f3ec2c29bd1cf3453ee3df66d2c245a") -- Tell Me Why Chapter 3
setManifestid(1266670, "3458796689156191626", 6104439167)

-- DLC's found!
addappid(1238430) -- Tell Me Why Chapter 2
addappid(1266670) -- Tell Me Why Chapter 3

