-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1230170)
addappid(1230171, 1, "157da1d72d7f391c2a6b5cb72842229b872eb822cfc9bdd3d271882ccae57381") 
setManifestid(1230171, "14712755296101741", 0)
