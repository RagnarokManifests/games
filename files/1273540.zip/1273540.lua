-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1273540)
addappid(1273541, 1, "4512476479ff9928f18955fcf32ca1d6e269de5cc6aafcf53882601f0afe4147")
setManifestid(1273541, "7790899100895540523", 3021331411)
-- addappid(1273542, 1, "7e7dd5d8d424b3419d4f4b24cd2dbe33e0366306450d53d44d6ae6b8c4c99cec")
-- setManifestid(1273542, "4117920976453583116", 3004321771)
addappid(1773880, 1, "d9b3b1ed60d9c111fea84d9c87a19abccff6bfc1ec63bb27829e10b8a9f4696d")
setManifestid(1773880, "1151595018996234060", 0)
addappid(1823720, 1, "dc723a70d7baca338ba087bfa5b0088ff18958a83707812eb14478c070d7e4d0")
setManifestid(1823720, "520994453214182245", 0)