-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1576420)
addappid(1576421, 1, "f76ad559310207144f63ba2498d5e424103d5beff81397496041435ac461684e")
setManifestid(1576421, "3373202489915929952")
