-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1583720)
addappid(1583721, 1, "5557bc8565d9e8785c7b3905b86faf8b5614b9dca33feb5002d16c9671947761")
setManifestid(1583721, "221358659444691228", 0)
addappid(1583722, 1, "d42338c0e8e8d4d2539f838a82c9574e5a8cdb0a9d148e0dc01a21a92e59ea65") 
setManifestid(1583722, "2657413625953743905", 0)
addappid(1583723, 1, "683ae974b6ca3e060888ff6f56206a42a01d4f4a158e397bdf39301432c40c15") 
setManifestid(1583723, "2336486362785684652", 0)
addappid(2143080)
addappid(2143081, 1, "5e8230c877b5c9c4bb0e1e8bd37da05cd402a7dce73d85ebaadf4b14f58b5691") 
setManifestid(2143081, "444103255941205270", 0)
