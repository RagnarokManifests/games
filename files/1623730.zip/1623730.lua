-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1623730)
addappid(1623731, 1, "7a422988135296505205dd489945d4b17ed7414734dd627744adac84aade7b73")
setManifestid(1623731, "3063864362474111121", 0)
addappid(2771110)
addappid(2771111, 1, "802dd0505be5518464fe77ed7afa2c28611463bf00ec5ef400643b323d09c4c7") 
setManifestid(2771111, "6472366291146846212", 0)
addappid(2771112, 1, "c385e52ae8ad3b8756ab3caa03e50b105c0157fb797bb5acbff1bbb8bb27692f") 
setManifestid(2771112, "4099416431916212746", 0)
