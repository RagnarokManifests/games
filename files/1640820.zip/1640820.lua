-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1640820)
addappid(1640821,0,"2de4c341c69a5caece120eed798bbd441bada826bdf8b1ea784ad8d1964397b9")
setManifestid(1640821,"119456162520934073")
addappid(1640822,0,"523e44823dd5e6b046a2f63a9d4c6cdea4d21188c21f153da271138c00b1685e")
setManifestid(1640822,"2110041086799325647")