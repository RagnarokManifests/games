-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(228989)
addappid(228990)
addappid(1721110)
addappid(1721111,0,"fd31fe45269b1676240f9cabc945952eddc0eca492eed6d02938264d045af58b")
addappid(3853680)
addappid(3853680)
addappid(3853800)
addappid(3853801,0,"3d1ec2cd4b3ab78e6b74d7ad261a0d77e657bedebadbf7ab6e1079545601cac3")
addappid(3853802,0,"d5a12418aca4da9a563c544f5fe7cc1ec2d17471f5f86cc5800ff6caab2fdb4c")
