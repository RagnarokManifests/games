-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1734680)
addappid(1734681,0,"c3acfe71f8b50f48def20ca9a792ed95da18b22dc3646150964e4c26fba47fc5")
setManifestid(1734681,"5307825177948483016")