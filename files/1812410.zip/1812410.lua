-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1812410)
addappid(1812411, 1, "0502c6aa05008975e99724561a19245f0fb3bb9ee53e2fe145fcb67f42c7d77b")
setManifestid(1812411, "3650862941770605908", 1216636683)