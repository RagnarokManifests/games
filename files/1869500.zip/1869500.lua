-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1869500)
addappid(1869501, 1, "49e36947f4a3b33907fb520e27d8d33ffd54d90fdbb2a3e7963d99f0397314bf")
addappid(1869502, 1, "08c7109feb33d3890e12f11a03df0ef36a7b49cad594b25bc01a8fcd29f1b251")
addappid(1869503, 1, "81d11a35c7a9beda96bc3d64012f32ec8893d8f44afe03de656db7e260fd8a94")
