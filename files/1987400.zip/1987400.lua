-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1987400)
addappid(1987401, 1, "1cc46fc317834519a61457e330644a3de76e9d3c6b86573e660a7c336284cc96")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(2167206, 1, "bf786e7e3bfad1988e39efa9b008ce875927b8e651351d4963f5c44643f0152b")
addappid(3881560)
addappid(3881560, 1, "a76d8138e7167fbee7d6bf0d80ba957dcabe4ed11105b69e52afdf8bbc971b68")