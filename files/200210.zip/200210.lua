-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(200210)
addappid(200211, 1, "9ae303368ff69745334984bde698e4e833d11fab5988a5e68be8f2fbe40f53eb")
setManifestid(200211, "3298159192732419112", 93944279)
-- addappid(200212, 1, "b650ff7755b7e5a88f6300810462e10ed91afae5d3846a62d33906699591db08")
-- setManifestid(200212, "6432862185852449077", 94968963)

-- DLCs without dedicated depots
addappid(270740) -- Realm of the Mad God Slime Priest Skin
addappid(270741) -- Realm of the Mad God Slime Archer Skin
addappid(270742) -- Realm of the Mad God Slime Knight Skin
addappid(270743) -- Realm of the Mad God Brigand Skin for the Rogue
addappid(270744) -- Realm of the Mad God Agent Skin for the Assassin
addappid(270745) -- Realm of the Mad God Gentleman Skin for the Wizard
addappid(294180) -- Realm of the Mad God Steam Booster Pack
addappid(308160) -- Realm of the Mad God Toy Knife Dagger
addappid(308161) -- Realm of the Mad God Unstable Anomaly Sword
addappid(308162) -- Realm of the Mad God Precisely Calibrated Stringstick Bow
addappid(308163) -- Realm of the Mad God Barely Attuned Magic Thingy Staff
addappid(308164) -- Realm of the Mad God Lethargic Sentience Wand
addappid(547760) -- Realm of the Mad God Super Adventurer Pack
addappid(548380) -- Realm of the Madgod Halloween Pack
addappid(556880) -- Realm of the Mad God Free Welcome Pack
addappid(1390710) -- Realm of the Mad God Exalt Pack
addappid(3306740) -- Realm of the Mad God Conquerors Pack
addappid(3306750) -- Realm of the Mad God Free Starter Pack
addappid(3306760) -- Realm of the Mad God Champions Pack
addappid(3306770) -- Realm of the Mad God Explorers Pack