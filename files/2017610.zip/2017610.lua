-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2017610)
addappid(2017611, 1, "1ef4f53fafeab2bca07a911a0cc4e1eca9200f8e4cb854d04add3e8ee9450f5f")
setManifestid(2017611, "8718264124785487837", 9278755650)