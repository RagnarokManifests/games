-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2058030)
addappid(2058031,0,"0d54e331589650da120f533f76fc488cedf68cd52d891b44a538648c28aa2e9d")
setManifestid(2058031,"8981463197589492768")