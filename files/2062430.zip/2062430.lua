-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2062430)
addappid(2062431,0,"5d28ee4226eb2240f32250a615d7cdf1e5beebec25073151597d734fc48d547c")
addappid(4091070)
