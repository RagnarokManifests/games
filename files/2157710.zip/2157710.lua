-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2157710)
addappid(2157711,0,"aae1b54d52d987432e2554037a1c3b2176de82193e23ac6613b422c4bbc15775")
setManifestid(2157711,"3335884955137950051")