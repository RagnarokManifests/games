-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(223710)
addappid(229002)
setManifestid(229002,"7260605429366465749")
addappid(229003)
setManifestid(229003,"8740933542064151477")
addappid(223711,3465817078078599269,"3a01e728a9a3a805348fc7a0fb00a6e22dae50b51c4981f131a54b919e00c8ec")