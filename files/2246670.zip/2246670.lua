-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2246670)
addappid(2246671, 1, "e144ac4eb76015ab095c549730d07519d9ae2916c28c7f6940bfd7a0d8eb6b35")
setManifestid(2246671, "5470154190148824852", 18271593841)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
setManifestid(228989, "3514306556860204959", 39590283)
addappid(2833370)
addappid(2833370, 1, "d5179861da87edc0542c6a0fe202ff8051045e81972da7091abb36632c215255")
setManifestid(2833370, "3906636434351247684", 925145538)
addappid(3106420)
addappid(3106420, 1, "cd0a4844be9f46cd490eb1d54db804db59255318c2e80366ffcdc1b848cbd01c")
setManifestid(3106420, "4033023325803216249", 4491)
addappid(3106430)
addappid(3106430, 1, "fb30f9c22a8920e904b9cf8f07f220e453cc576b8db97d1e751220329b617b4f")
setManifestid(3106430, "8410528672328740297", 4529)
addappid(3106440)
addappid(3106440, 1, "1af6fd9f43a86c1c34dc0b5d3974cd214bf31f30aa4de2a3797f46875b0a1ba7")
setManifestid(3106440, "1142284471696305737", 118592834)
addappid(3106450)