-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2277560)
addappid(2277561, 1, "6db3af8b5be3def24c758a005feb7fa0f65750716392328e2f14321340adb273")
setManifestid(2277561, "2647147609698210830", 0)
addappid(3653760)
addappid(3653770)
addappid(3653790)
addappid(3758190)
