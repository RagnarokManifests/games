-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2348730)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2348732,0,"1db34303394ca3a9c48e61c3cf6eb8d9a64a4b95765c951f7a7ec1561977f6e3")
setManifestid(2348732,"2313551624888458186")
