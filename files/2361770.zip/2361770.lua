-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2361770)
addappid(2361771,0,"6077dc2b1a88a7ae7a34470113e609a77bfc721374f4b17e20abc2f975ad2d85")
setManifestid(2361771,"7116288504888504901")
addappid(3381250,0,"155147f9c285079d0c8de3a293bb7e0ebc4c5e59763e5eb6f6ddb5a14c37df25")
setManifestid(3381250,"2060539196030722798")