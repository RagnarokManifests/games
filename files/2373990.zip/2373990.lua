-- 2373990's Lua and Manifest Created by Morrenus
-- Solo Leveling: ARISE OVERDRIVE
-- Created: November 28, 2025 at 20:12:46 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2373990) -- Solo Leveling: ARISE OVERDRIVE
-- MAIN APP DEPOTS
addappid(2373991, 1, "5a97586d39bdb2a503376a75e3cae7d1f7e2de1bcb9ced523a73b21ca79de413") -- Depot 2373991
setManifestid(2373991, "5369177369412766959", 43879671729)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3638570) -- Solo LevelingARISE OVERDRIVE - Deluxe Edition