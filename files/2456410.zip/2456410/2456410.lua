-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2456410)
addappid(2456411,0,"e18e6d39466db8f0bd67c36735438bbc461df2aecb0f97fe6a0bcedaf8cff368")
setManifestid(2456411,"5577989960355444942")