addappid(2488370)
addappid(3660310)
addappid(2488372,0,"977e890c85c823ca9de5001068b30e038ade55c019c6e777e357cea4c148f33b")
setManifestid(2488372,"7463189476838988869")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]