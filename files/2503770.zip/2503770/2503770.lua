-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2503770)
addappid(2503771,1,"13bc89e933d261de7af8bc6b3535e664a82327d9c80adeadbdc74f485d4c939f")
setManifestid(2503771,"4824813336966241858",1856591398)
