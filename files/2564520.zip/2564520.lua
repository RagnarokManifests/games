addappid(2564520)
addappid(3573930)
addappid(2564521,0,"4b679f8c7ffc59c1398369a7bb72987e78717c22d81ec186eb11bb0cc0e5f6e8")
addappid(3478380,0,"08b4f767f1591c4c96ec034dd7c78d0d442ac1d6c39586fff1ece5f94a7e4e6c")
setManifestid(2564521,"388399390072352571")
setManifestid(3478380,"8473010599245403699")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]