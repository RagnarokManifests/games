-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2589820)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2589821,0,"645d3cf9c7e24c84f861e22bfc2f93554967af472c63d347ff3fac12c4819f4c")
setManifestid(2589821,"8156899762171626669")