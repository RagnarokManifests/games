-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2611170)
addappid(2611171,0,"1f598e428d7d0e64b1aec12ea34871b5a8ae2d9c917da54934d656a8b75dfa7b")
setManifestid(2611171,"1729555504482342429")