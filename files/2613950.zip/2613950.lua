-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2613950)
addappid(2613951,0,"298b10be2cce7ae9ad5e5acb64e48c100ab6be5af21ed54ffbd5210212f9c4da")
setManifestid(2613951,"4818995176246964871")