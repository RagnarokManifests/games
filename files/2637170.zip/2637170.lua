-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2637170)
addappid(2637171,0,"c60e18fca5cd831027c052d7c58b4c8f9d15bb4153515cbcebfc7d68ab52b7d0")
setManifestid(2637171,"3260015169014461731")