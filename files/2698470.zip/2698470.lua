-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2698470)
addappid(2698471,0,"95f3343c9904bd90d71885d3b2eb6746835ec58ad09848c91df7260a0c3460cd")
addappid(3888580,0,"5db81899667392d2240d375b096693438142e88700954b729101615c9f941c9e")
