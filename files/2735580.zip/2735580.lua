-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2735580)
addappid(2735583, 1, "c55904da7d44d2a56d195136d0a47a4c722bd166cd278e69055417c1972b39be")
setManifestid(2735583, "7746154466015506250", 0)
