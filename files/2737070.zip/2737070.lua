-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2737070)
addappid(2737071,0,"36e272c2274c8d6dbf4a697d1faa618de36bbacf8439215d60cca4350601aedb")
setManifestid(2737071,"2542679740768906713")