-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2800080)
addappid(2800081, 1, "97e6b86cbd24c949ee37e954ed05c6c6a874270cf39a3ba8759228d80abbbc67")