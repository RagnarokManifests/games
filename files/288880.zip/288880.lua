-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(288880)
addappid(288881, 1, "8faf4642f8f9c9b10051894985c1e32bf055b424b2f136108dd4fb895321b601")
setManifestid(288881, "9160203053510340681", 2535750218)