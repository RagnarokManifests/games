-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2893570)
addappid(2893571, 1, "511f158856c1819c10a9d2916437455351f4fde9144e27c85cdbd64769037309")
setManifestid(2893571, "2485611735242171593", 17042305432)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
setManifestid(228990, "1829726630299308803", 102931551)
addappid(3707290)
addappid(3707300)
addappid(3707310)
addappid(3904130)
addappid(3904140)
addappid(3904280)