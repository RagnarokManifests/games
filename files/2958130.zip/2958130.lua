-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(2958130, 1, "28c45829d1af12623b4fead679e384291bfb040d0241fc6be9d05f7d4cdbbd62")
addappid(2958131, 1, "dc7cb4cb8d7d76fdcab84fed34fa1f799e7459cf1be5ed041116ed846211889d")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(3651190)
addappid(3651200)