-- 299970's Lua and Manifest Created by Morrenus
-- Project Motor Racing
-- Created: November 28, 2025 at 18:21:45 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 3

-- MAIN APPLICATION
addappid(299970) -- Project Motor Racing
-- MAIN APP DEPOTS
addappid(299971, 1, "627b7ea547216da3a24888dc32bd27fa27c0f3bfae47a0e15b6a6a3c905bfa07") -- Depot 299971
setManifestid(299971, "1419181304016282171", 51533450587)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3660380) -- Project Motor Racing Group 5 Revival Pack
addappid(3660390) -- Project Motor Racing GTE Decade Pack
addappid(3660400) -- Project Motor Racing Year 1 Season Pass