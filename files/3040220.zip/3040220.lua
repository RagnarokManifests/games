-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3040220)
addappid(3040221,0,"4e420c4703c98612bdd32e142ab68e49de39d49835b722b523ddede7ae026a17")
setManifestid(3040221,"8341763148768809613")