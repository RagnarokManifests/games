addappid(3061570,1,"8f227cc26032b926449ae8071f369e5c9c574c8e32a11927c7595fd2552a447c")
addappid(3061571,0,"08c9bf8c96295b965da7d11e5262f6d143a4ec15b8697d994997f14df4bf7f38")
addappid(3061572,0,"c9af8bc6dcbbbec05d5f14bd8925fdfbad45a319fb067f32493d00266cf6d49a")
setManifestid(3061571,"8317008798694582729")
setManifestid(3061572,"8247658173662561960")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]