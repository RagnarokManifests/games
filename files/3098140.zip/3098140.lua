-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3098140)
addappid(3098141, 1, "fd797fa8dd21e697a60ebe34ae9376d72af28d3efd07a78be6a7c8873ce4a2b0")
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c")
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")