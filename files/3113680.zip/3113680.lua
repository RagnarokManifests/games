-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3113680)
addappid(3113681, 1, "174d479a2c0657ad7755534a7a005230bebfbedd36f2ee0607d3354b5ea0b9b2")
setManifestid(3113681, "3231586409429918804", 0)
