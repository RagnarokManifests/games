-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3135840)
addappid(3135841,0,"33cfd586fbc494197f3819b255cd3d8dc976af6447db5160395d23d95c704b30")
setManifestid(3135841,"905038632235064938")