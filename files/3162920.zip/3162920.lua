-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3162920)
addappid(3162921, 1, "e13569dc04cf2da0fb6e7df7392779ffa57cac35213ac20e9d79cd429ff46d6f")
setManifestid(3162921, "7245283223066108310", 3502433525)