-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3201910)
addappid(3201911, 1, "46a048eabbe26d9436a14036da2caa89bb0aedc6120abe014d8a647ca5abb411")
setManifestid(3201911, "2479084903564176737", 0)
addappid(3601390) -- RailGods of Hysterra - Supporter Pack (with depots)
addappid(3601390, 1, "64ba32802db186b2061a124acd28e1c105394eaee551f5249aa0bdba82704e39")
setManifestid(3601390, "5779026321098797952", 0)