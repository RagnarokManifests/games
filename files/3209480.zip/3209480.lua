-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3209480)
addappid(3209481,0,"cd783437d27e2a39f961592e9b07cea05662d93e0799c248158afdbd8b1fb1d8")
setManifestid(3209481,"8524687911932301224")