-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3218530)
addappid(3218531,0,"50ece9f8ddbf60ec708059b18a272a27ce8789161e30aaa57626720f4496c173")
setManifestid(3218531,"2803707833736246223")