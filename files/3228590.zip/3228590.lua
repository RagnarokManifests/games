-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3228590)
addappid(3228591, 1, "ff50f696309f1bdaedc819a0dfc5ad20497d9884179b19683f5ceba047094567")
setManifestid(3228591, "5295022108040833692", 7032911052)