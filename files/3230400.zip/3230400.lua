-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3230400)
addappid(3230401, 1, "d27469f0328400d0e61683059a3ad3824df4c1c1ae36fe6933dcfb093d01440a")
addappid(3230402, 1, "82076c00a744f17dab06a0c6b804a4be4e36589ceff9c4a6cd31bba837e1e203")
addappid(3340991, 1, "023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")
addappid(3415740)