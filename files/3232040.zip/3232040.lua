-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3232040)
addappid(3232041, 1, "da1d750063dc152ed92f546b7e0fa06d9adb3944c4fa4b8797697e6f8e637f2d"))
setManifestid(3232041, "7635449925138223101", 0)
addappid(229005, 1, "aa18a527cdc103aeb3d12caafd6f581689a14467aa55658ba583a9af6e90313a") 
setManifestid(229005, "7992454656023763365", 0)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") 
setManifestid(229007, "4477590687906973371", 0)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") 
setManifestid(229020, "5799761707845834510", 0)
addappid(229033, 1, "9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3")
setManifestid(229033, "2059065101492814639", 0)
