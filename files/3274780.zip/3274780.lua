-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3274780) 
addappid(3274781, 1, "72f44c4af109194137d7f4a21e4d00cbeff452b97f6d22afaa6a43b5f65cb56b")
setManifestid(3274781, "5842556629252893915", 0)
