-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3285500)
addappid(3285501, 1, "d540ff5a3e564eb42dd7bc7fcd2767ba878e869bde88b3b99f21372cf43fe116")
setManifestid(3285501, "4527884125216010644", 4151083062)
addappid(3786750, 1, "8ea8b93dc597304b744fb21727c260bb3f2940dde0fc68d4cce2c9c1a2cdbecf")
setManifestid(3786750, "541906025618108742", 14686913)