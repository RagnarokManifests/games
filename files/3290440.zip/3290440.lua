-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3290440)
addappid(3290441,0,"7475f5e3685ef11c9c2a0e4c635671ec9f4585d3735b9ade062be22989493264")
setManifestid(3290441,"1283730590245369991")