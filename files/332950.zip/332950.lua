-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(332950)
setManifestid(228981,"7613356809904826842")
setManifestid(228982,"6413394087650432851")
setManifestid(228983,"8124929965194586177")
setManifestid(228984,"2547553897526095397")
setManifestid(228985,"3966345552745568756")
setManifestid(228986,"8782296191957114623")
setManifestid(228987,"4302102680580581867")
setManifestid(228990,"1829726630299308803")
setManifestid(229030,"1043465440436835055")
setManifestid(229031,"7746630274301172884")
setManifestid(229032,"3616495131483866412")
setManifestid(229033,"2059065101492814639")
addappid(332951,0,"6a39198ed2507581c09af1361425691fc64d1fd13d251b5b951e011d2dbaf3cd")
setManifestid(332951,"179954252936033447")