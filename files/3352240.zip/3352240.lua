-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords


addappid(3352240)
addappid(3352241,0,"6a82f2c4778c4822edb4e249b8d269bcc004d047eb7dc974c21f99202939ab5c")