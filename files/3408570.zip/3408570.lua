-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3408570)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(3408571,0,"c70bfe0b7c52fb90fd7e465354417c4cbd1617494219c3a3150cfc2ec341e1ef")
setManifestid(3408571,"7652753997556425101")