-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3446200)
addappid(3446201, 1, "cfbf694f31ee8e4a28819ae123115bf23ade614b426f3c0a92c477cc32bcba85")
setManifestid(3446201, "5729207495342442990", 0)