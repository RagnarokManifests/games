-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3551340)
addappid(3551341, 1, "a4f9c46a0797978fa0b278dac08a0f473872fc74c6b6d9bf45b30d56e33a42c7")
addappid(3551342, 1, "31edad03a3daebca77afad83adb899f2ff6611d949738ad3d15e708da8f2c7ca")
addappid(3551343, 1, "5ff6a006dff3e4ea6364310a8390ffc5f4754c3928150ea5719009c21074a607")
addappid(3551410)