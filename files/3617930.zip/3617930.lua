-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3617930)
addappid(3617931,0,"203f99afbb35d4f0ec24b6d272b7f578112aef1037b7afd140a7d536ed9b2e22")
setManifestid(3617931,"252312111063068613")