-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3668080)
addappid(3668081, 1, "57e8358dc923a421319fe11031a8cbada4031105c13786c9ef4c08b4cd67d05c")
setManifestid(3668081, "964622677976562474", 6599368746)