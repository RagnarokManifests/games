-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(3668370)
addappid(3668371, 1, "980df52f8f9145bce6710c1de03dd3e91fce5c30ba47bf36ef798b1217b54718")