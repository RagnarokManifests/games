-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(447270)
addappid(447271, 1, "b7b2182a4287a29c792507a40f3e991eff6be2702cfa8346de9b253098cd9980")
setManifestid(447271, "2176721654666722274", 0)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") 
setManifestid(228985, "3966345552745568756", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") 
setManifestid(228990, "1829726630299308803", 0)
