addappid(458430)
addappid(3626530)
addappid(458432,0,"676d0c262af24e6cd734932d053a9997f4e69a5226ac436b337b04054884257a")
addappid(3626520,0,"9e6ccdec2df7d0d334069f38327098dd7fad54e37fc15d75f364187201721c2d")
setManifestid(458432,"5824819597308936952")
setManifestid(3626520,"4513624616451772644")


--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]