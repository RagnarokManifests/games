-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(490110) 
addappid(490111, 1, "44bcc3870bf156385e37ff47e71ae28824fa905a542cdc8eaf05715799f78fc2")
setManifestid(490111, "5248906601395034933", 0)
