-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(513710)
addappid(228987)
setManifestid(228987,"4302102680580581867")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(513711,0,"a4217026617fd23bbc1b544c3160c7c7e5157bc3cfcd825b8dbd1c6d0513c3b4")
setManifestid(513711,"2375672516653307792")
addappid(919680,0,"903d006bb149ccbe1ab4f9dbbad34150079380811c9c78b3cfa5c1505ad889ae")
setManifestid(919680,"6252294094855435400")
addappid(1643210,0,"9e747e8f5cf60151ff0c48ce9eb2bb1977b88052fbb610f1a0ae88d28d001194")
setManifestid(1643210,"8526987047835682522")