-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(577940)
addappid(577941, 1, "369c2eb2f233f274457b6a59f16d4caf8e4bd979815beecc1406415d0486fe5a")
setManifestid(577941, "8536967100852291423", 52729409117)

-- DLCs without dedicated depots
addappid(2625580) -- Killer Instinct Anniversary Edition