-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(621060)
addappid(621061, 1, "1d1b57e233552bf36e85de21663fda41d1160d3d446649bf0f1013a8d344ef01")
setManifestid(621061, "8059996378040224226", 23950326345)
addappid(621062, 1, "d762715b8415a1f887f261e5a1736c7e86ad1fe5f77d2e945fcd61b255689df4")
setManifestid(621062, "5241418081171311864", 23975265925)
addappid(621064, 1, "99c73cc41569fc2a0dcf0a31e01100910dbc13d02796e59d4690779c435b3e69")
setManifestid(621064, "7462877534655878177", 1070336258)
addappid(621066, 1, "3f4ffa558cfb78f1d55d918c35023414f578b0e4e5bb46521b5e6bccf312e5fe")
setManifestid(621066, "2389478938334206964", 1557944285)
addappid(823721, 1, "df05eaae0ca49058c5fa7ded79d21ac2171492bedd24043a4e20c0f481046f87")
setManifestid(823721, "1129732127197775673", 85253062)
addappid(973911, 1, "a8d8b7263cd12d4e507235de6387d9836de57c8b5db216718fc39efd10ce4fa3")
setManifestid(973911, "2685826651630361507", 318104503)
addappid(973913, 1, "158dc9df98251a4f530488d790133a004eca4e54662ce3af07e281d09877ccf6")
setManifestid(973913, "5196682258430873488", 1287934612)
addappid(1067591, 1, "6f7750fbf846134738d1cc1217eb3fd4c3b2ab8b01b72632418bab461bd567a9")
setManifestid(1067591, "4596798953497399210", 1245580957)
addappid(1252991, 1, "81f5c96180e9d56dc4420bc2a12234569b73ee31ed2f2caa32cb7e0f6c64422e")
setManifestid(1252991, "5962469216062900967", 4801242285)
addappid(1295801, 1, "399e0f27eb31954c73fd4dab64bc4bdf6f9f52296c83dd359c9b5701d30cd883")
setManifestid(1295801, "1453017817142136898", 1538879796)
addappid(1416671, 1, "5009289fe0dffa35b19502e8a4c051eba4c86568544c752b14f9bc45893755a3")
setManifestid(1416671, "7591920544321803732", 1285857302)
addappid(1591921, 1, "fdc918ec5412354aac886f088b9effeba01f8cd808aca3b20ac8d1cea92aae26")
setManifestid(1591921, "7737755154255796550", 2004062849)

-- DLCs without dedicated depots
addappid(823720) -- PC Building Simulator - Good Company Case
addappid(973910) -- PC Building Simulator - Overclocked Edition Content
addappid(982590) -- PC Building Simulator - Razer Workshop
addappid(982600) -- PC Building Simulator - Deadstick Case
addappid(1067590) -- PC Building Simulator - Republic of Gamers Workshop
addappid(1198960) -- PC Building Simulator - NZXT Workshop
addappid(1252990) -- PC Building Simulator - Esports Expansion
addappid(1295800) -- PC Building Simulator - Overclockers UK Workshop
addappid(1416670) -- PC Building Simulator - AORUS Workshop
addappid(1591920) -- PC Building Simulator - EVGA Workshop
addappid(1642950) -- PC Building Simulator - Fractal Design Workshop