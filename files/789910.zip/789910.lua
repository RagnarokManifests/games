-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(789910)
setManifestid(228986,"8782296191957114623")
setManifestid(228990,"1829726630299308803")
addappid(789911,0,"0ff37e60674b9d687db1304ed7cf7b9d1be166c03a96f63954aaf54df2cc4e1d")
setManifestid(789911,"8231813725299187341")