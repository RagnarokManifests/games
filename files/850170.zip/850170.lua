-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(850170)
addappid(850171, 1, "6090bf1ee1d2a41e5508537c28e84b6eea51d774b841eaf4ee9b51637a081291")
setManifestid(850171, "8600652106843921209", 0)
addappid(850172, 1, "aa065557f7c98c8e40679ff83caa3c2626826e3bd56d93d0cd2f4b8ca9a1592d")
setManifestid(850172, "3295503679796576126", 0)
addappid(850173, 1, "ff87a1b152a382fe473065ebeac492cb811c929956c194888925ba89abb23876")
setManifestid(850173, "5175676960907506931", 0)