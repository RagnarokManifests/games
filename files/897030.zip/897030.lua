-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(897030)
addappid(897031,0,"121df8019615dfc24824c49230be55a687b716a8f812914f47c81435236f330b")
setManifestid(897031,"891452666567716630")
addappid(897033,0,"3048d5048f7680ea8e9bb04e6f8c44303056cadab43f50e4d80ea4fd5dcb009b")
setManifestid(897033,"8331549144474005233")
addappid(897032,0,"9d059d66d40e12f844c5c725e5863d8e56aeb0fde32a01646561675615cb4401")
setManifestid(897032,"2758619414953168120")
addappid(897034,0,"460fb43c405b5a1bceabf7f5d6b80e217d03dbc68f24650c152dae6f3f62205f")
setManifestid(897034,"8719473682295074943")
addappid(897036,0,"d2625198977f25e28d9f73336999bbb23adc23c1557c1aa16a4ff09491b3fe2f")
setManifestid(897036,"795052707102860901")
addappid(897035,0,"38258099eadd72efebb0e3c941795891c0dfe6b29fe33eed7bd8b88a90ed759e")
setManifestid(897035,"2355842398581172504")
addappid(903460)