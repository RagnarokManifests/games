-- 1091500's Lua and Manifest Created by Hubcap Manifest
-- Cyberpunk 2077
-- Created: October 23, 2026 at 09:35:43 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 26161058 (public branch)
-- Build Date: October 23, 2026 at 09:12:36 EDT (1792761156)
-- Total Depots: 47
-- Total DLCs: 3
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1091500, 1, "cf941dce25dfe9090877d385fca0ded473ecc1e12a09e28698b5c8dd3c134598") -- Cyberpunk 2077
-- MAIN APP DEPOTS
addappid(1091501, 1, "fd4524cb30582752f15e4bf01254dbb7b890f58008101a40208cd78fb139d800") -- Cyberpunk 2077 Content
setManifestid(1091501, "3524634124112875626", 66818683782)
addappid(1091502, 1, "90dd5a17a45ff0595a7ed6366d0fea078e8c362633ebbe6382c173d736063b72") -- Cyberpunk 2077 Speech PL
setManifestid(1091502, "4172273210291337333", 5030207488)
addappid(1091503, 1, "b2606cbfc79b86f848e75dbf59afeeae8a1d5c08523111dcdbeace51b69ec48c") -- Cyberpunk 2077 Speech RU
setManifestid(1091503, "4993759022489533495", 5493030912)
addappid(1091504, 1, "c874647c72c73e87686ecef42bd4c0fbc8e564be98bb0c20c487807c2c4d8d47") -- Cyberpunk 2077 Speech FR
setManifestid(1091504, "5442389038065566384", 5148045312)
addappid(1091505, 1, "8382ac2e50bd6c716f748eefe9aa9a7e4ccafe5f4f2d7a19f01e5d5d2d096864") -- Cyberpunk 2077 Speech IT
setManifestid(1091505, "2934902767306624465", 5340307456)
addappid(1091506, 1, "794d47675f8d91a58528e4b7e0bb347d1c542ccdd48eeda5a796b7c1af663e08") -- Cyberpunk 2077 Speech DE
setManifestid(1091506, "2215112025565446036", 5233995776)
addappid(1091507, 1, "ad400264d25291632ad0c35e48e98ae3ada3c411a7ed946bacbdfaa80fd0dd00") -- Cyberpunk 2077 Speech ES
setManifestid(1091507, "5146069936114903922", 5582753792)
addappid(1091508, 1, "fa0ebf333c7ac4828a8a38fd9c646543a872965d3bf1b5e205fa176dc1e93337") -- Cyberpunk 2077 Speech JP
setManifestid(1091508, "8531150390463106452", 5015560192)
addappid(1091509, 1, "987c3b4b920a2258661e62065089d398fcc2412b300355c47a2655b4b373fafa") -- Cyberpunk 2077 Speech ZH
setManifestid(1091509, "7209153223914178735", 5008642048)
addappid(1460470, 1, "97d6dfacfdc6ba0678277cfbdc4f38b561807a3fb8679513411c7b9e819195b3") -- Cyberpunk 2077 Speech KO
setManifestid(1460470, "6531889808105063031", 5141458944)
addappid(1460471, 1, "20f9808b7948ce1d4b7b16d660e745ce5f251bd0e40c18d8a4072d7f944eb56e") -- Cyberpunk 2077 Speech BRPT
setManifestid(1460471, "68619443676863989", 5268271104)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITH DEDICATED DEPOTS
-- Cyberpunk 2077 REDmod (AppID: 2060310)
addappid(2060310)
addappid(2060310, 1, "45cf0829a4dae87f0f1b263c92df30079111d1dd697bb87d6830f21e04fdf8a0") -- Cyberpunk 2077 REDmod - Cyberpunk 2077 Test (2060310) Depot
setManifestid(2060310, "4793018690565322422", 634683704)
-- Cyberpunk 2077 Phantom Liberty (AppID: 2138330)
-- DLCS WITHOUT DEDICATED DEPOTS